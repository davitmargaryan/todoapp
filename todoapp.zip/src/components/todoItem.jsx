import React, { Component } from 'react';
import Checkbox from "@material-ui/core/Checkbox";
import Fab from "@material-ui/core/Fab";
import DeleteIcon from "@material-ui/icons/Delete";
import { withStyles } from '@material-ui/core/styles';

const styles = theme => ({
    fab: {
        margin: theme.spacing.unit,
    },
    todoName: {
        width: 200
    },
    todoItem: {
        display: 'flex',
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center'
    }
});

class TodoItem extends Component {
    onTodoStatusChange = (e)=>{
        const {updateTodoItem, todo} = this.props;
        updateTodoItem({
            ...todo,
            status: e.target.checked ? 'completed' : 'active'
        })
    };
    onRemoveTodoClick = ()=>{
        const {removeTodo, todo}  = this.props;
        removeTodo(todo);
    };

    render() {
        const { todo, classes } = this.props;
        const classForTest = todo.status === 'active' ? 'test-unchecked-test' : 'test-checked-test';
        const color = todo.status === 'active' ? 'black' : 'grey';
        return (
            <div className={classes.todoItem}>
                <Checkbox
                    checked={todo.status === 'completed'}
                    onChange={this.onTodoStatusChange}
                    value="checkedB"
                    color="primary"
                />
                {/*<input className={classForTest} checked={todo.status === 'completed'} onChange={this.onTodoStatusChange} type="checkbox"/>*/}
                <div className={classes.todoName} style={{color}}>{todo.name}</div>
                <Fab size="small" onClick={this.onRemoveTodoClick} aria-label="Delete" className={classes.fab}>
                    <DeleteIcon />
                </Fab>
                {/*<button onClick={this.onRemoveTodoClick}>X</button>*/}
            </div>
        );
    }
}

export default withStyles(styles)(TodoItem);
