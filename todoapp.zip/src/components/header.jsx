import React, { Component } from 'react';
import uniqid from 'uniqid';
import Button from "@material-ui/core/Button";
import { withStyles } from '@material-ui/core/styles';
import TextField from "@material-ui/core/TextField";

const styles = theme => ({
    button: {
        margin: theme.spacing.unit,
    },
    textField: {
        marginLeft: theme.spacing.unit,
        marginRight: theme.spacing.unit,
        width: 200,
    },
    todoHeader: {
        width: 600,
        margin: '0 auto',
        display: 'flex',
        justifyContent: 'center'
    }
});

class Header extends Component {
    state = {
        name: ''
    };
    handleChange = (e) => {
        this.setState({name: e.target.value})
    };
    onAddButtonClick =()=>{
        const {addTodo} = this.props;
        const {name} = this.state;
        const id = uniqid();
        const newTodoItem = {
            name,
            id,
            status: 'active'
        };
        addTodo(newTodoItem).then(()=>{
            this.setState({name: ''})
        }).catch(e=>alert(e.message));
    };
    handleKeyPress = (e) => {
        if(e.which === 13){
            this.onAddButtonClick();
        }
    };

    inputProps = {
        onKeyPress: this.handleKeyPress
    };

    render() {
        const {classes} = this.props;
        const { name } = this.state;
        return (
            <div className={classes.todoHeader}>
                <TextField
                    autoFocus
                    inputProps={this.inputProps}
                    className={classes.textField}
                    value={name}
                    onChange={this.handleChange}
                    margin="normal"
                />
                <Button onClick={this.onAddButtonClick} color="primary" className={classes.button}>Add</Button>
            </div>
        );
    }
}

export default withStyles(styles)(Header);
