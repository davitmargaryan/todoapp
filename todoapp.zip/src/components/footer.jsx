import React, {Component} from 'react';
import { withStyles } from '@material-ui/core/styles';
import Button from "@material-ui/core/es/Button";

const styles = theme => ({
    todoFooter: {
        width: 600,
        margin: '0 auto',
        display: 'flex',
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center'
    },
    button: {
        margin: theme.spacing.unit
    }
});

class Footer extends Component {
    render() {
        const {activeCount, completedCount, clearCompleted, showCompletedTodos, showActiveTodos, showAllTodos, classes} = this.props;
        return (
            <div className={classes.todoFooter}>
                <div>{activeCount} items left</div>
                <div>
                    <Button className={classes.button} color="primary" variant="outlined" onClick={showAllTodos}>All</Button>
                    <Button className={classes.button} color="primary" variant="outlined" onClick={showActiveTodos}>Active</Button>
                    <Button className={classes.button} color="primary" variant="outlined" onClick={showCompletedTodos}>Completed</Button>
                </div>
                {!!completedCount && (
                    <div>
                        <Button className={classes.button} color="primary" variant="outlined" onClick={clearCompleted}>Clear completed</Button>
                    </div>
                )}
            </div>
        );
    }
}

export default withStyles(styles)(Footer);
