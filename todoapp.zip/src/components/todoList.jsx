import React, {Component} from 'react';
import TodoItem from "./todoItem";

class TodoList extends Component {
    render() {
        const {todoList, filter} = this.props;
        const filteredTodos = filter === 'all' ? todoList : todoList.filter(todo => todo.status === filter);
        return (
            <div className="todo-list">
                {filteredTodos.map((todo, index) =>
                    <TodoItem key={todo.id.toString()}
                              todo={todo} updateTodoItem={this.props.updateTodoItem}
                              removeTodo={this.props.removeTodo}/>
                )}
            </div>
        );
    }
}

export default TodoList;
