import React, {Component} from 'react';
import './App.css';
import Header from "./components/header";
import TodoList from "./components/todoList";
import Footer from "./components/footer";

class App extends Component {

    state = {
        todoList: [],
        completedCount: 0,
        activeCount: 0,
        filter: 'all'
    };

    updateTodoItem = (todo) => {
        const {todoList, activeCount, completedCount} = this.state;
        const updatingTodoIndex = todoList.indexOf(todoList.filter(item => item.id === todo.id)[0]);
        if (updatingTodoIndex === -1) {
            return;
        }
        const newTodoList = [...todoList];
        newTodoList.splice(updatingTodoIndex, 1, todo);
        if (todo.status === 'active') {
            this.setState({todoList: newTodoList, completedCount: completedCount - 1, activeCount: activeCount + 1})
        } else {
            this.setState({todoList: newTodoList, completedCount: completedCount + 1, activeCount: activeCount - 1})
        }

    };
    addTodo = (todo) => {
        return new Promise((resolve, reject) => {
            const {todoList, activeCount} = this.state;
            const exists = todoList.filter(item => item.name === todo.name);
            if (exists.length) {
                reject(new Error(`Todo with "${todo.name}" name already exists`))
            } else {
                this.setState({todoList: [...this.state.todoList, todo], activeCount: activeCount + 1});
                resolve('success')
            }

        });
    };
    removeTodo = (todo) => {
        const {todoList, activeCount, completedCount} = this.state;
        const updatingTodoIndex = todoList.indexOf(todo);
        if (updatingTodoIndex === -1) {
            console.log(todo);
            return;
        }
        const newTodoList = [...todoList];
        newTodoList.splice(updatingTodoIndex, 1);
        if (todo.status === 'active') {
            this.setState({todoList: newTodoList, activeCount: activeCount - 1})
        } else {
            this.setState({todoList: newTodoList, completedCount: completedCount - 1})
        }
    };
    showAllTodos = () => {
        this.setState({filter: 'all'})
    };
    showActiveTodos = () => {
        this.setState({filter: 'active'})
    };
    showCompletedTodos = () => {
        this.setState({filter: 'completed'})
    };
    clearCompleted = () => {
      const {todoList} = this.state;
      const newTodoList = todoList.filter(todo => todo.status === 'active');
      this.setState({todoList: newTodoList});
    };

    render() {
        const {todoList, activeCount, completedCount, filter} = this.state;
        return (
            <>
                <Header addTodo={this.addTodo}/>
                <TodoList filter={filter} todoList={todoList} updateTodoItem={this.updateTodoItem}
                          removeTodo={this.removeTodo}/>
                {!!todoList.length &&
                <Footer completedCount={completedCount} activeCount={activeCount} showAllTodos={this.showAllTodos}
                        showActiveTodos={this.showActiveTodos} showCompletedTodos={this.showCompletedTodos} clearCompleted={this.clearCompleted}/>}
            </>
        );
    }
}

export default App;
